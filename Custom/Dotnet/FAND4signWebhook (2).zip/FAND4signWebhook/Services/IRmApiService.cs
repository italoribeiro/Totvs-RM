using FAND4signWebhook.Models;

namespace FAND4signWebhook.Services
{
    /// <summary>
    /// Define o contrato para o serviço de comunicação com a API do RM.
    /// </summary>
    public interface IRmApiService
    {
        /// <summary>
        /// Envia o payload do webhook para a API do RM de forma assíncrona.
        /// </summary>
        /// <param name="payload">Os dados recebidos do D4Sign.</param>
        /// <returns>True se o envio for bem-sucedido, False caso contrário.</returns>
        Task<bool> EnviarPayloadAsync(D4SignPayload payload);
    }
}