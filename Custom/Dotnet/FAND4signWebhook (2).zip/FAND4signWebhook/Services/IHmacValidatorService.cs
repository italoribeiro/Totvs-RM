namespace FAND4signWebhook.Services
{
    /// <summary>
    /// Define o contrato para o serviço de validação HMAC.
    /// </summary>
    public interface IHmacValidatorService
    {
        /// <summary>
        /// Verifica a assinatura HMAC SHA256 do D4Sign.
        /// </summary>
        /// <param name="uuid">O UUID do documento recebido no payload.</param>
        /// <param name="hmacHeader">O valor do header 'Content-Hmac'.</param>
        /// <returns>True se a assinatura for válida, False caso contrário.</returns>
        bool IsValid(string uuid, string hmacHeader);
    }
}