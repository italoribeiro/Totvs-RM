using FAND4signWebhook.Models;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace FAND4signWebhook.Services
{
    /// <summary>
    /// Implementação do serviço que envia dados para a API do RM (Totvs).
    /// </summary>
    public class RmApiService : IRmApiService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<RmApiService> _logger;

        public RmApiService(
            IHttpClientFactory httpClientFactory, 
            IConfiguration configuration, 
            ILogger<RmApiService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<bool> EnviarPayloadAsync(D4SignPayload payload)
        {
            try
            {
                // 1. Ler configurações da API do RM
                var settings = _configuration.GetSection("RmApiSettings");
                var baseUrl = settings["BaseUrl"];
                var endpointId = settings["EndpointId"];
                var username = settings["Username"];
                var password = settings["Password"];

                // 2. Montar o HttpClient
                var client = _httpClientFactory.CreateClient("RmApiClient");
                client.BaseAddress = new Uri(baseUrl ?? "");

                // 3. Gerar o token Basic Auth
                var authToken = Convert.ToBase64String(
                    Encoding.UTF8.GetBytes($"{username}:{password}")
                );
                client.DefaultRequestHeaders.Authorization = 
                    new AuthenticationHeaderValue("Basic", authToken);

                // 4. "Traduzir" o payload do D4Sign para o payload do RM
                var rmPayload = new RmApiPayload
                {
                    Uuid = payload.uuid,
                    TypePost = payload.type_post,
                    Message = payload.message,
                    Email = payload.email
                };

                // 5. Executar a chamada de rede (curl) de forma ASSÍNCRONA
                HttpResponseMessage response = await client.PostAsJsonAsync(endpointId, rmPayload);

                //
                // --- ATUALIZAÇÃO V2.5 ---
                // Lemos o conteúdo da resposta (o JSON de retorno)
                // independentemente de ter sido sucesso ou falha.
                string responseContent = await response.Content.ReadAsStringAsync();
                //
                // --- FIM DA ATUALIZAÇÃO ---
                //

                // 6. Verificar se a API do RM respondeu com sucesso
                if (response.IsSuccessStatusCode)
                {
                    // ATUALIZADO: Adicionamos a 'responseContent' ao log
                    _logger.LogInformation(
                        "Payload {Uuid} enviado com sucesso para API do RM. Status: {StatusCode}. Resposta: {Response}",
                        payload.uuid,
                        response.StatusCode,
                        responseContent); // <-- AQUI ESTÁ A RESPOSTA
                        
                    return true;
                }
                
                // 7. A API do RM retornou um erro (4xx, 5xx)
                _logger.LogWarning(
                    "API do RM falhou ao processar {Uuid}. Status: {StatusCode}. Resposta: {Error}",
                    payload.uuid,
                    response.StatusCode,
                    responseContent); // <-- Usamos a mesma variável
                
                return false;
            }
            // 8. Capturar erros de ambiente (rede, timeout, DNS)
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Erro de rede ao tentar conectar com a API do RM para o UUID {Uuid}.", payload.uuid);
                return false;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "Timeout (TaskCanceledException) ao conectar com a API do RM para o UUID {Uuid}.", payload.uuid);
                return false;
            }
            // 9. Capturar qualquer outro erro inesperado
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro inesperado ao tentar enviar payload para o RM. UUID: {Uuid}", payload.uuid);
                return false;
            }
        }
    }
}