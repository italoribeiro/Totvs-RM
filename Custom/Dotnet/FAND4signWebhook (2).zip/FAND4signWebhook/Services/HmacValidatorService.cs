using System.Security.Cryptography;
using System.Text;

namespace FAND4signWebhook.Services
{
    /// <summary>
    /// Implementação do serviço de validação de assinatura HMAC.
    /// </summary>
    public class HmacValidatorService : IHmacValidatorService
    {
        private readonly string _secretKey;
        private readonly ILogger<HmacValidatorService> _logger;

        public HmacValidatorService(IConfiguration configuration, ILogger<HmacValidatorService> logger)
        {
            _logger = logger;
            _secretKey = configuration["D4SignSettings:HmacSecretKey"] ?? "";

            if (string.IsNullOrEmpty(_secretKey) || _secretKey == "COLOQUE-SUA-SECRET-KEY-HMAC-AQUI")
            {
                _logger.LogCritical("ERRO DE CONFIGURAÇÃO: 'D4SignSettings:HmacSecretKey' não está definida.");
                throw new InvalidOperationException("Chave secreta HMAC não configurada.");
            }
        }

        public bool IsValid(string uuid, string hmacHeader)
        {
            try
            {
                var hashPrefix = "sha256=";
                if (!hmacHeader.StartsWith(hashPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogWarning("Validação HMAC falhou: Header não inicia com 'sha256='.");
                    return false;
                }

                var receivedHash = hmacHeader.Substring(hashPrefix.Length);
                var secretBytes = Encoding.UTF8.GetBytes(_secretKey);
                var uuidBytes = Encoding.UTF8.GetBytes(uuid);

                using var hmac = new HMACSHA256(secretBytes);
                var computedHashBytes = hmac.ComputeHash(uuidBytes);
                var computedHashHex = Convert.ToHexString(computedHashBytes).ToLower();

                // Comparação segura de hashes
                return CryptographicOperations.FixedTimeEquals(
                    Encoding.UTF8.GetBytes(computedHashHex),
                    Encoding.UTF8.GetBytes(receivedHash)
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro inesperado durante a validação HMAC.");
                return false;
            }
        }
    }
}