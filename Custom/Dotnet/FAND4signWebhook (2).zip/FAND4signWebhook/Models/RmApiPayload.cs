using System.Text.Json.Serialization;

namespace FAND4signWebhook.Models
{
    /// <summary>
    /// Representa o payload (JSON) a ser enviado para a API do RM (Totvs).
    /// </summary>
    public class RmApiPayload
    {
        [JsonPropertyName("UUID")]
        public string Uuid { get; set; } = string.Empty;

        [JsonPropertyName("TYPE_POST")]
        public string TypePost { get; set; } = string.Empty;

        [JsonPropertyName("MESSAGE")]
        public string Message { get; set; } = string.Empty;

        [JsonPropertyName("EMAIL")]
        public string? Email { get; set; }
    }
}