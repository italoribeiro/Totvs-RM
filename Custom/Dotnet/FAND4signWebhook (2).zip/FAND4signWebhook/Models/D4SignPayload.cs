namespace FAND4signWebhook.Models
{
    /// <summary>
    /// Representa o payload (JSON) recebido do webhook do D4Sign.
    /// </summary>
    public record D4SignPayload(
        string uuid,
        string type_post,
        string message,
        string? email
    );
}